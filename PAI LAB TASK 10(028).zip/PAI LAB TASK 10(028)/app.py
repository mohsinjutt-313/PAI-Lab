from flask import Flask, render_template, request, jsonify

app = Flask(__name__)

knowledge_bases = {
    "University Admission Chatbot": {
        "requirements": "Admission requirements vary by program, but most require a completed application, academic transcripts, a statement of purpose, and letters of recommendation.",
        "deadlines": "Undergraduate deadlines are usually January 15 for fall admission and October 1 for spring admission. Graduate deadlines depend on the program; please check the specific department page.",
        "programs": "We offer undergraduate, graduate, and certificate programs in engineering, business, computer science, liberal arts, and health sciences.",
        "default": "Ask me about admission requirements, application deadlines, or program information."
    },
    "Medical Center Information Bot": {
        "appointments": "To schedule an appointment, call our main number or use the online booking portal. Walk-ins are accepted in many departments, depending on availability.",
        "departments": "Our medical center includes cardiology, pediatrics, general surgery, radiology, and more. Each department has a dedicated care team.",
        "doctors": "You can search doctors by specialty, location, or availability on our website. We also have family physicians, specialists, and consultants.",
        "default": "I can help with appointments, departments, and doctor information for the medical center."
    },
    "Hospital Information Chatbot": {
        "emergency": "Emergency services are open 24/7. Head to the emergency entrance or call our emergency hotline immediately.",
        "room availability": "Room availability changes frequently. Contact hospital admissions for current bed status in general, private, or ICU rooms.",
        "visiting hours": "Visiting hours are from 9 AM to 8 PM daily for most wards. ICU and neonatal units may have special restrictions.",
        "default": "Ask about emergency care, room availability, or visiting hours at the hospital."
    },
    "Hotel Information Chatbot": {
        "room types": "We offer single, double, deluxe, and suite rooms. Each room includes free Wi-Fi, breakfast, and 24-hour room service.",
        "prices": "Room prices start at $120 per night for a standard room, $180 for deluxe, and $250 for suites. Prices vary by season and availability.",
        "amenities": "Amenities include a fitness center, pool, spa, complimentary breakfast, airport shuttle, and free parking.",
        "booking": "To book a room, choose your dates on our booking page or call reservations. We offer free cancellation up to 48 hours before check-in.",
        "default": "I can provide room types, prices, amenities, and booking details for the hotel."
    },
    "Restaurant Information Bot": {
        "menu": "Our menu features appetizers, salads, mains, desserts, and daily specials. Vegetarian, vegan, and gluten-free options are available.",
        "reservations": "Reservations can be made online or by phone. We recommend booking in advance for weekend dining.",
        "order tracking": "For order tracking, please provide your order number or contact our takeout desk. Delivery times depend on current kitchen load.",
        "default": "Ask me about the menu, reservation status, or order tracking at the restaurant."
    },
    "Library Assistant Bot": {
        "find books": "You can search the catalog by title, author, or subject. If you need help locating a book, I can suggest the call number and section.",
        "due dates": "Due dates are printed on your checkout receipt. Most books are due in 2 weeks, while short-loan items are due in 3 days.",
        "opening hours": "The library is open Monday through Friday from 8 AM to 10 PM, and Saturday/Sunday from 10 AM to 6 PM.",
        "default": "I can help you find books, check due dates, or share library opening hours."
    }
}

@app.route("/")
def home():
    bot_names = list(knowledge_bases.keys())
    return render_template("index.html", bot_names=bot_names)

@app.route("/chat", methods=["POST"])
def chat():
    data = request.get_json() or {}
    bot_name = data.get("bot")
    message = (data.get("message") or "").strip().lower()

    if bot_name not in knowledge_bases:
        return jsonify({"reply": "Please select one of the available bots from the list."})

    knowledge = knowledge_bases[bot_name]
    response = knowledge["default"]

    if "requirement" in message or "admission" in message or "transcript" in message or "recommendation" in message:
        response = knowledge.get("requirements", response)
    elif "deadline" in message or "apply" in message or "deadline" in message:
        response = knowledge.get("deadlines", response)
    elif "program" in message or "course" in message or "major" in message:
        response = knowledge.get("programs", response)
    elif "appointment" in message or "book" in message or "schedule" in message:
        response = knowledge.get("appointments", response)
    elif "department" in message or "cardiology" in message or "pediatrics" in message or "radiology" in message:
        response = knowledge.get("departments", response)
    elif "doctor" in message or "physician" in message or "specialist" in message:
        response = knowledge.get("doctors", response)
    elif "emergency" in message or "urgent" in message or "accident" in message:
        response = knowledge.get("emergency", response)
    elif "room" in message and "avail" in message or "bed" in message:
        response = knowledge.get("room availability", response)
    elif "visit" in message or "hour" in message or "visiting" in message:
        response = knowledge.get("visiting hours", response)
    elif "room type" in message or "suite" in message or "single" in message or "double" in message:
        response = knowledge.get("room types", response)
    elif "price" in message or "cost" in message or "rate" in message:
        response = knowledge.get("prices", response)
    elif "amenity" in message or "pool" in message or "wifi" in message or "breakfast" in message:
        response = knowledge.get("amenities", response)
    elif "book" in message and "hotel" not in message or "booking" in message or "reserve" in message:
        response = knowledge.get("booking", response)
    elif "menu" in message or "dish" in message or "order" in message or "special" in message:
        response = knowledge.get("menu", response)
    elif "reservation" in message or "table" in message or "reserve" in message:
        response = knowledge.get("reservations", response)
    elif "order tracking" in message or "track" in message or "status" in message:
        response = knowledge.get("order tracking", response)
    elif "find" in message or "locate" in message or "book" in message and "library" in bot_name.lower() or "catalog" in message:
        response = knowledge.get("find books", response)
    elif "due date" in message or "due" in message or "return" in message or "renew" in message:
        response = knowledge.get("due dates", response)
    elif "open" in message or "hour" in message or "schedule" in message:
        response = knowledge.get("opening hours", response)

    return jsonify({"reply": response})

if __name__ == "__main__":
    app.run(debug=True)
