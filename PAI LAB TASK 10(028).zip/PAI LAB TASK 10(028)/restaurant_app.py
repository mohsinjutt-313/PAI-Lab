from flask import Flask, render_template, request, jsonify

app = Flask(__name__)

restaurant_knowledge = {
    "menu": "Our restaurant menu includes appetizers, salads, mains, desserts, and daily specials. Vegetarian, vegan, and gluten-free options are available.",
    "reservations": "Reservations can be made online or by phone. We recommend booking in advance for weekends and special events.",
    "order tracking": "To track your order, please provide your order number or contact the takeout desk. Delivery and pickup times depend on current kitchen load.",
    "opening hours": "We are open Monday to Thursday from 11 AM to 10 PM, Friday and Saturday from 11 AM to 11 PM, and Sunday from 10 AM to 9 PM.",
    "location": "We are located at 123 Main Street, right in the heart of downtown, with easy parking nearby.",
    "default": "Hi! Ask me about our menu, reservations, order tracking, opening hours, or restaurant services."
}

@app.route("/")
def home():
    return render_template("restaurant.html")

@app.route("/chat", methods=["POST"])
def chat():
    data = request.get_json() or {}
    message = (data.get("message") or "").strip().lower()
    response = restaurant_knowledge["default"]

    if any(keyword in message for keyword in ["menu", "dish", "special", "appetizer", "dessert", "vegetarian", "vegan"]):
        response = restaurant_knowledge["menu"]
    elif any(keyword in message for keyword in ["reserve", "reservation", "book", "table", "booking"]):
        response = restaurant_knowledge["reservations"]
    elif any(keyword in message for keyword in ["track", "status", "order", "delivery", "pickup"]):
        response = restaurant_knowledge["order tracking"]
    elif any(keyword in message for keyword in ["open", "hour", "hours", "time", "closed"]):
        response = restaurant_knowledge["opening hours"]
    elif any(keyword in message for keyword in ["location", "address", "where", "parking"]):
        response = restaurant_knowledge["location"]

    return jsonify({"reply": response})

if __name__ == "__main__":
    app.run(debug=True)
