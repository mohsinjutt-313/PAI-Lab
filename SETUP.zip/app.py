from flask import Flask, render_template, request, jsonify
import requests
from datetime import datetime, timedelta
import json

app = Flask(__name__)

# Alpha Vantage API key (free tier)
# You can get a free API key from: https://www.alphavantage.co/
API_KEY = "demo"  # Replace with your actual API key from alpha vantage
ALPHA_VANTAGE_BASE_URL = "https://www.alphavantage.co/query"

# Cache for API responses to avoid rate limiting
stock_cache = {}
CACHE_DURATION = 300  # 5 minutes in seconds


def is_cache_valid(symbol):
    """Check if cached data is still valid"""
    if symbol in stock_cache:
        cached_time = stock_cache[symbol].get('timestamp')
        if cached_time and (datetime.now() - cached_time).seconds < CACHE_DURATION:
            return True
    return False


def get_stock_data(symbol):
    """Fetch stock data from Alpha Vantage API"""
    symbol = symbol.upper()
    
    # Check cache first
    if is_cache_valid(symbol):
        return stock_cache[symbol]['data']
    
    try:
        params = {
            'function': 'GLOBAL_QUOTE',
            'symbol': symbol,
            'apikey': API_KEY
        }
        
        response = requests.get(ALPHA_VANTAGE_BASE_URL, params=params, timeout=10)
        response.raise_for_status()
        data = response.json()
        
        if 'Global Quote' in data and data['Global Quote']:
            quote = data['Global Quote']
            
            # Check if we got a valid response
            if 'Symbol' in quote and quote['Symbol']:
                result = {
                    'symbol': quote.get('01. symbol', 'N/A'),
                    'price': float(quote.get('05. price', 0)) or 0,
                    'change': float(quote.get('09. change', 0)) or 0,
                    'changePercent': quote.get('10. change percent', '0%'),
                    'timestamp': quote.get('07. latest trading day', 'N/A'),
                    'open': float(quote.get('02. open', 0)) or 0,
                    'high': float(quote.get('03. high', 0)) or 0,
                    'low': float(quote.get('04. low', 0)) or 0,
                    'volume': quote.get('06. volume', 'N/A'),
                    'prevClose': float(quote.get('08. previous close', 0)) or 0,
                }
                
                # Cache the result
                stock_cache[symbol] = {
                    'data': result,
                    'timestamp': datetime.now()
                }
                
                return result
            else:
                return {'error': 'Stock symbol not found. Please check the symbol and try again.'}
        
        return {'error': 'Unable to fetch stock data. Please try again later.'}
    
    except requests.exceptions.Timeout:
        return {'error': 'Request timed out. Please try again.'}
    except requests.exceptions.RequestException as e:
        return {'error': f'Error fetching data: {str(e)}'}
    except Exception as e:
        return {'error': f'An error occurred: {str(e)}'}


def get_intraday_data(symbol):
    """Fetch intraday time series data for charting"""
    symbol = symbol.upper()
    
    try:
        params = {
            'function': 'TIME_SERIES_INTRADAY',
            'symbol': symbol,
            'interval': '60min',
            'apikey': API_KEY
        }
        
        response = requests.get(ALPHA_VANTAGE_BASE_URL, params=params, timeout=10)
        response.raise_for_status()
        data = response.json()
        
        time_series_key = 'Time Series (60min)'
        
        if time_series_key in data:
            time_series = data[time_series_key]
            
            # Get last 10 data points
            labels = []
            prices = []
            
            for timestamp in sorted(list(time_series.keys())[-10:]):
                labels.append(timestamp.split(' ')[1])  # Get time only
                prices.append(float(time_series[timestamp]['4. close']))
            
            return {
                'labels': labels,
                'prices': prices,
                'success': True
            }
        
        return {'success': False, 'message': 'No data available'}
    
    except Exception as e:
        return {'success': False, 'message': str(e)}


@app.route('/')
def index():
    """Main page"""
    return render_template('index.html')


@app.route('/api/stock/<symbol>', methods=['GET'])
def get_stock(symbol):
    """API endpoint to get stock data"""
    data = get_stock_data(symbol)
    return jsonify(data)


@app.route('/api/chart/<symbol>', methods=['GET'])
def get_chart_data(symbol):
    """API endpoint to get chart data"""
    data = get_intraday_data(symbol)
    return jsonify(data)


@app.route('/api/search', methods=['POST'])
def search_stock():
    """Search for a stock"""
    data = request.json
    symbol = data.get('symbol', '').strip()
    
    if not symbol:
        return jsonify({'error': 'Symbol cannot be empty'}), 400
    
    stock_data = get_stock_data(symbol)
    return jsonify(stock_data)


@app.errorhandler(404)
def not_found(error):
    """Handle 404 errors"""
    return jsonify({'error': 'Not found'}), 404


@app.errorhandler(500)
def server_error(error):
    """Handle 500 errors"""
    return jsonify({'error': 'Server error'}), 500


if __name__ == '__main__':
    app.run(debug=True, port=5000)
