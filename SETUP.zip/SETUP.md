## ⚡ Quick Start Guide - Stock Price Tracker

### 🎯 What is This?
A Flask-based web application that displays real-time stock prices and interactive charts using the Alpha Vantage API.

---

## 🚀 Quick Setup (2 Minutes)

### 1️⃣ Install Dependencies
```bash
pip install -r requirements.txt
```

### 2️⃣ Run the Application
```bash
python app.py
```

### 3️⃣ Open in Browser
Go to: **http://localhost:5000**

---

## 🎯 How to Use

1. **Type a Stock Symbol**: AAPL, GOOGL, MSFT, TSLA, etc.
2. **Click Search** or press **Enter**
3. **View Real-Time Data**:
   - Current Price
   - Daily Change
   - High/Low/Volume
   - Interactive Chart

4. **Quick Buttons**: Click popular stocks at the bottom

---

## 🔑 Get Free API Key (Recommended)

The app works with the demo API key but has rate limits:
- **Demo API**: 5 requests/minute, 100/day
- **Free API Key**: Better limits at no cost

### Steps:
1. Visit: https://www.alphavantage.co/
2. Get your free API key
3. Open `app.py` (line 10)
4. Replace: `API_KEY = "demo"` with your actual key

---

## 📁 Project Files

```
PAI LAB TASK 08(028)/
├── app.py                  ← Flask backend
├── requirements.txt        ← Dependencies  
├── README.md              ← Full documentation
├── SETUP.md              ← This file
├── templates/
│   └── index.html        ← Frontend
└── static/
    ├── css/
    │   └── style.css     ← Styling
    └── js/
        └── script.js     ← Interactions
```

---

## 🌟 Features

✅ Real-time stock prices  
✅ Interactive charts (60-min updates)  
✅ Quick access to 8 popular stocks  
✅ Mobile responsive design  
✅ Beautiful gradient UI  
✅ Error handling  
✅ API response caching  

---

## ⚠️ Troubleshooting

### Issue: "ModuleNotFoundError: No module named 'flask'"
```bash
pip install -r requirements.txt
```

### Issue: "Address already in use"
- Port 5000 is occupied
- Edit `app.py` line 158: change `port=5000` to `port=5001`

### Issue: "Stock symbol not found"
- Check spelling (AAPL, not APPLE)
- Try: MSFT, GOOGL, AMZN

### Issue: Chart not showing
- Normal - it requires intraday data
- Works for active market hours

---

## 🎨 Customization

### Change Port
Edit last line of `app.py`:
```python
app.run(debug=True, port=5001)  # Change to any port
```

### Change Colors
Edit `static/css/style.css` lines 6-14:
```css
--primary-color: #1e3a8a;  /* Blue */
--secondary-color: #3b82f6;  /* Light Blue */
```

### Change Default Stocks
Edit `templates/index.html` buttons section for quick search stocks

---

## 📊 Stock Data Endpoints

Test these URLs in your browser:
- `http://localhost:5000/api/stock/AAPL` - Get AAPL data
- `http://localhost:5000/api/chart/MSFT` - Get MSFT chart data

---

## 📌 Common Stock Symbols

| Company | Symbol |
|---------|--------|
| Apple | AAPL |
| Google | GOOGL |
| Microsoft | MSFT |
| Amazon | AMZN |
| Tesla | TSLA |
| Meta | META |
| NVIDIA | NVDA |
| JP Morgan | JPM |

---

## 💡 Tips

- **Cache**: Results cached 5 minutes to avoid API limits
- **Charts**: Show 60-min data during market hours
- **Mobile**: Fully responsive on phones/tablets
- **Dark Mode**: You can add by modifying CSS

---

## 🛑 Stop the Application

Press `CTRL + C` in the terminal where the app is running.

---

## 📞 Support

For full documentation, see **README.md**

**Need API key?** Visit https://www.alphavantage.co/

**Questions about Flask?** https://flask.palletsprojects.com/

---

**Happy Trading! 📈**
