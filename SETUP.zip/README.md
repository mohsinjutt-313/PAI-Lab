# Stock Price Tracker - Flask Web Application

A dynamic web application that provides real-time stock market data using the Alpha Vantage API.

## Features

✨ **Core Features:**
- 📊 Real-time stock price tracking
- 📈 Intraday price charts with Chart.js
- 🔍 Search for any stock symbol
- ⚡ Quick access to popular stocks (AAPL, GOOGL, MSFT, AMZN, TSLA, etc.)
- 📱 Fully responsive design (mobile, tablet, desktop)
- 💾 API response caching (5 minutes)
- 🎨 Modern, sleek UI with gradient design

## Stock Information Displayed

- Current Price
- Daily Change & Change Percentage
- Opening Price
- Daily High & Low
- Trading Volume
- Previous Close Price
- Last Updated Timestamp
- 60-minute intraday price chart

## Technologies Used

### Backend
- **Flask** - Web framework
- **Python 3.x** - Backend language
- **Requests** - HTTP library for API calls

### Frontend
- **HTML5** - Markup
- **CSS3** - Styling with gradient and animations
- **JavaScript (Vanilla)** - Dynamic functionality
- **Chart.js** - Interactive price charts

### API
- **Alpha Vantage** - Free stock market data API

## Installation & Setup

### Prerequisites
- Python 3.7 or higher
- pip (Python package manager)

### Step 1: Clone/Download the Project
```bash
cd PAI\ LAB\ TASK\ 08\(028\)
```

### Step 2: Create Virtual Environment (Optional but Recommended)
```bash
# On Windows
python -m venv venv
venv\Scripts\activate

# On macOS/Linux
python3 -m venv venv
source venv/bin/activate
```

### Step 3: Install Dependencies
```bash
pip install -r requirements.txt
```

### Step 4: Get a Free API Key (Optional but Recommended)
1. Visit [Alpha Vantage](https://www.alphavantage.co/)
2. Sign up for a free API key
3. Open `app.py` and replace `API_KEY = "demo"` with your actual key:
   ```python
   API_KEY = "your_api_key_here"
   ```

**Note:** The "demo" API key has rate limiting. A free API key allows 5 requests per minute and 100 requests per day.

### Step 5: Run the Application
```bash
python app.py
```

### Step 6: Access the Application
Open your web browser and navigate to:
```
http://localhost:5000
```

## How to Use

1. **Search for a Stock:**
   - Enter a stock symbol (e.g., AAPL for Apple)
   - Click the "Search" button or press Enter
   - View detailed stock information and charts

2. **Use Quick Search:**
   - Click any of the popular stock buttons at the bottom
   - Apple (AAPL), Google (GOOGL), Microsoft (MSFT), etc.

3. **View Chart:**
   - The intraday price chart shows 60-minute candlesticks
   - Hover over points to see detailed prices
   - Green chart = price going up, Red chart = price going down

## API Endpoints

### Get Stock Quote
```
GET /api/stock/<symbol>
```
Returns current stock data including price, change, and volume.

**Example:**
```
GET /api/stock/AAPL
```

### Get Chart Data
```
GET /api/chart/<symbol>
```
Returns intraday time series data for chart visualization.

**Example:**
```
GET /api/chart/AAPL
```

### Search Stock
```
POST /api/search
Content-Type: application/json

{
    "symbol": "AAPL"
}
```

## Project Structure

```
PAI LAB TASK 08(028)/
├── app.py                    # Flask application & API endpoints
├── requirements.txt          # Python dependencies
├── README.md                 # This file
├── templates/
│   └── index.html           # Main HTML template
└── static/
    ├── css/
    │   └── style.css        # Styling
    └── js/
        └── script.js        # Frontend logic & interactions
```

## Key Features Explained

### 1. **Real-time Data**
- Fetches latest stock quotes from Alpha Vantage API
- Updates display instantly upon search

### 2. **Caching System**
- Results cached for 5 minutes to avoid rate limiting
- Improves performance for repeated searches

### 3. **Error Handling**
- User-friendly error messages
- Handles API errors gracefully
- Validates input before requests

### 4. **Responsive Design**
- Mobile-first approach
- Works perfectly on smartphones, tablets, and desktops
- Touch-friendly buttons and inputs

### 5. **Dynamic Charts**
- Uses Chart.js for beautiful, interactive charts
- Shows 60-minute intraday price movements
- Color-coded based on price direction (green/red)

### 6. **Stock Information Display**
- Comprehensive stock metrics
- Quick stat cards for easy scanning
- Clear change indicators with percentages

## Customization

### Change API Provider
To use a different stock API (Yahoo Finance, IEX Cloud, etc.), modify the `get_stock_data()` and `get_intraday_data()` functions in `app.py`.

### Modify Chart Interval
Change the `interval` parameter in `get_intraday_data()`:
- `1min` - 1-minute intervals
- `5min` - 5-minute intervals
- `15min` - 15-minute intervals
- `30min` - 30-minute intervals
- `60min` - 60-minute intervals (default)

### Customize Colors
Edit CSS variables in `static/css/style.css`:
```css
:root {
    --primary-color: #1e3a8a;
    --secondary-color: #3b82f6;
    --success-color: #10b981;
    --danger-color: #ef4444;
    /* ... more colors ... */
}
```

## Limitations & Notes

1. **API Rate Limits:**
   - Free tier: 5 requests/minute, 100 requests/day
   - Upgrade for higher limits

2. **Market Hours:**
   - Stock quotes only available during market trading hours
   - Weekend/holiday data shows previous close

3. **Data Delay:**
   - Free tier may have slight delays
   - Premium tier provides real-time data

4. **Browser Compatibility:**
   - Works on all modern browsers (Chrome, Firefox, Safari, Edge)
   - Requires JavaScript enabled

## Troubleshooting

### Issue: "Stock symbol not found" error
- Check spelling of stock symbol
- Ensure symbol is valid (3-4 letter ticker)
- Try popular stocks like AAPL, MSFT

### Issue: API rate limit exceeded
- Wait a few minutes before next request
- Get a free API key from Alpha Vantage
- Upgrade to a paid plan for higher limits

### Issue: Chart not showing
- This is optional functionality
- Check browser console for errors (F12)
- Chart requires valid intraday data

### Issue: Application won't start
- Verify Python 3.7+ is installed
- Ensure virtual environment is activated (if used)
- Check all dependencies installed: `pip install -r requirements.txt`

## Security Notes

- API key should not be shared publicly
- Never commit actual API keys to version control
- Use environment variables for production deployment
- Validate all user input

## Performance Tips

1. **Caching:** Results are cached for 5 minutes to reduce API calls
2. **Lazy Loading:** Chart only loads when data is available
3. **Minification:** Consider minifying CSS/JS for production
4. **CDN:** Chart.js is loaded from CDN for faster loading

## Future Enhancements

- [ ] Historical price charts (weekly/monthly)
- [ ] Stock comparison tool
- [ ] Portfolio tracking
- [ ] Price alerts/notifications
- [ ] Save favorite stocks
- [ ] Dark mode
- [ ] Stock news integration
- [ ] Technical indicators (SMA, RSI, MACD)

## Credits

- **API:** [Alpha Vantage](https://www.alphavantage.co/)
- **Chart Library:** [Chart.js](https://www.chartjs.org/)
- **Framework:** [Flask](https://flask.palletsprojects.com/)

## License

This project is open source and available under the MIT License.

## Support & Contact

For issues or questions:
1. Check the Troubleshooting section
2. Review API documentation at Alpha Vantage
3. Check browser console for error messages

---

**Happy Trading! 📈**

Last Updated: April 2026
