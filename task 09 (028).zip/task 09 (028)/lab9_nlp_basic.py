# Programming for Artificial Intelligence - Lab 9 (Basics of NLP)
# Task: Basic NLP Pipeline with Sentiment Analysis and Text Classification
# Libraries used: nltk, textblob, sklearn
# Author: [Your Name]
# Date: [Submission Date]

# ---------------------------
# Import required libraries
# ---------------------------
import nltk
from nltk.tokenize import word_tokenize
from nltk.corpus import stopwords, wordnet
from nltk.stem import PorterStemmer, WordNetLemmatizer
from textblob import TextBlob
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.naive_bayes import MultinomialNB

# Download necessary NLTK data files (only needed once)
nltk.download('punkt')
nltk.download('stopwords')
nltk.download('wordnet')
nltk.download('omw-1.4')

# ---------------------------
# Sample Data
# ---------------------------
# A sample paragraph for NLP processing
sample_text = """
Natural Language Processing (NLP) is a fascinating field of Artificial Intelligence.
It allows computers to understand, interpret, and generate human language.
I love learning about NLP! Sometimes, it can be challenging, but it's very rewarding.
"""

# For text classification, we need labeled data (very simple example)
train_texts = [
    "I love this product, it is amazing and works great!",    # Positive
    "This is the worst experience I have ever had.",          # Negative
    "Absolutely fantastic! Highly recommend to everyone.",    # Positive
    "I am very disappointed and unhappy with the service.",   # Negative
]
train_labels = ['positive', 'negative', 'positive', 'negative']

# ---------------------------
# 1. Tokenization
# ---------------------------
# Tokenization splits text into individual words (tokens)
tokens = word_tokenize(sample_text)
print("Tokens:")
print(tokens)
print()

# ---------------------------
# 2. Stopword Removal
# ---------------------------
# Stopwords are common words (like 'the', 'is', 'and') that add little meaning
stop_words = set(stopwords.words('english'))
filtered_tokens = [word for word in tokens if word.lower() not in stop_words and word.isalpha()]
print("Filtered Tokens (after stopword removal):")
print(filtered_tokens)
print()

# ---------------------------
# 3. Stemming
# ---------------------------
# Stemming reduces words to their root form (e.g., 'learning' -> 'learn')
stemmer = PorterStemmer()
stemmed_words = [stemmer.stem(word) for word in filtered_tokens]
print("Stemmed Words:")
print(stemmed_words)
print()

# ---------------------------
# 4. Lemmatization
# ---------------------------
# Lemmatization reduces words to their base form using vocabulary and morphology (e.g., 'better' -> 'good')
lemmatizer = WordNetLemmatizer()
lemmatized_words = [lemmatizer.lemmatize(word) for word in filtered_tokens]
print("Lemmatized Words:")
print(lemmatized_words)
print()

# ---------------------------
# 5. Sentiment Analysis (TextBlob)
# ---------------------------
# Sentiment analysis determines the polarity (positive/negative) and subjectivity of text
blob = TextBlob(sample_text)
sentiment = blob.sentiment
print("Sentiment Analysis:")
print(f"Polarity: {sentiment.polarity} (range: -1 negative, 1 positive)")
print(f"Subjectivity: {sentiment.subjectivity} (range: 0 objective, 1 subjective)")
print()

# ---------------------------
# 6. Text Classification (Naive Bayes)
# ---------------------------
# We'll classify a new sentence as positive or negative using a simple Naive Bayes classifier

# Step 1: Vectorize the text (convert text to numbers)
vectorizer = CountVectorizer()
X_train = vectorizer.fit_transform(train_texts)

# Step 2: Train the Naive Bayes classifier
classifier = MultinomialNB()
classifier.fit(X_train, train_labels)

# Step 3: Classify a new sentence
test_sentence = "The service was excellent and I am very happy."
X_test = vectorizer.transform([test_sentence])
predicted_label = classifier.predict(X_test)[0]

print("Text Classification:")
print(f"Test Sentence: {test_sentence}")
print(f"Predicted Sentiment: {predicted_label}")

# ---------------------------
# Sample Output (for reference)
# ---------------------------
# Tokens:
# ['Natural', 'Language', 'Processing', '(', 'NLP', ')', 'is', 'a', 'fascinating', 'field', 'of', 'Artificial', 'Intelligence', '.', ...]
#
# Filtered Tokens (after stopword removal):
# ['Natural', 'Language', 'Processing', 'NLP', 'fascinating', 'field', 'Artificial', 'Intelligence', 'allows', 'computers', 'understand', 'interpret', 'generate', 'human', 'language', 'love', 'learning', 'NLP', 'Sometimes', 'challenging', 'rewarding']
#
# Stemmed Words:
# ['natur', 'languag', 'process', 'nlp', 'fascin', 'field', 'artifici', 'intellig', 'allow', 'comput', 'understand', 'interpret', 'generat', 'human', 'languag', 'love', 'learn', 'nlp', 'sometim', 'challeng', 'reward']
#
# Lemmatized Words:
# ['Natural', 'Language', 'Processing', 'NLP', 'fascinating', 'field', 'Artificial', 'Intelligence', 'allows', 'computers', 'understand', 'interpret', 'generate', 'human', 'language', 'love', 'learning', 'NLP', 'Sometimes', 'challenging', 'rewarding']
#
# Sentiment Analysis:
# Polarity: 0.375 (range: -1 negative, 1 positive)
# Subjectivity: 0.75 (range: 0 objective, 1 subjective)
#
# Text Classification:
# Test Sentence: The service was excellent and I am very happy.
# Predicted Sentiment: positive
