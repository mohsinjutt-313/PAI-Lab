from flask import Flask, request, render_template
import pandas as pd
import numpy as np
import faiss
from transformers import AutoTokenizer, AutoModel
import torch
import os

qna_df = pd.read_csv('Chapter19.csv')
question_col = 'Question'  
answer_col = 'Answer'      
qna_pairs = list(zip(qna_df[question_col], qna_df[answer_col]))

def clean_text(text):
    import re
    text = str(text).strip().lower()
    text = re.sub(r'[^\w\s]', '', text)
    return text

tokenizer = AutoTokenizer.from_pretrained('sentence-transformers/all-MiniLM-L6-v2')
model = AutoModel.from_pretrained('sentence-transformers/all-MiniLM-L6-v2')

def get_embedding(text):
    encoded_input = tokenizer(text, padding=True, truncation=True, return_tensors='pt')
    with torch.no_grad():
        model_output = model(**encoded_input)
    embeddings = model_output.last_hidden_state.mean(dim=1)
    return embeddings[0].numpy()

question_embeddings = np.array([get_embedding(clean_text(q)) for q, a in qna_pairs])
embedding_dim = question_embeddings.shape[1]
index = faiss.IndexFlatL2(embedding_dim)
index.add(question_embeddings)

def search_qna(query, top_k=3):
    query_vec = get_embedding(clean_text(query)).reshape(1, -1)
    D, I = index.search(query_vec, top_k)
    results = []
    for idx in I[0]:
        q, a = qna_pairs[idx]
        results.append({'question': q, 'answer': a})
    return results

app = Flask(__name__)

@app.route('/', methods=['GET', 'POST'])
def home():
    results = None
    if request.method == 'POST':
        query = request.form['query']
        results = search_qna(query)
    return render_template('index.html', results=results)

if __name__ == '__main__':
    app.run(port=5000, debug=True)
