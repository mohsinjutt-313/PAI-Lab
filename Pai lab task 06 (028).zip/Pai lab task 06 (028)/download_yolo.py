"""Utility to download YOLOv3 weights, cfg, and coco names.
Usage:
    python download_yolo.py
"""

import os
import urllib.request

BASE_URL = "https://pjreddie.com/media/files/"
MODEL_URL = BASE_URL + "yolov3.weights"
CFG_URL = "https://raw.githubusercontent.com/pjreddie/darknet/master/cfg/yolov3.cfg"
NAMES_URL = "https://raw.githubusercontent.com/pjreddie/darknet/master/data/coco.names"

os.makedirs("models", exist_ok=True)

print("Downloading YOLOv3 weights (200+ MB). This may take several minutes...")
urllib.request.urlretrieve(MODEL_URL, "models/yolov3.weights")
print("Downloaded weights")
print("Downloading cfg and names...")
urllib.request.urlretrieve(CFG_URL, "models/yolov3.cfg")
urllib.request.urlretrieve(NAMES_URL, "models/coco.names")
print("Done. files saved in models/")
