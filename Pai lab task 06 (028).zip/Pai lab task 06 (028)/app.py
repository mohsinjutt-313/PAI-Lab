import os
from flask import Flask, render_template, request, redirect, url_for, send_from_directory, flash
from werkzeug.utils import secure_filename
from detection import AnimalDetector, draw_boxes
import cv2
from PIL import Image
from PIL.ExifTags import TAGS

UPLOAD_FOLDER = "static/uploads"
OUTPUT_FOLDER = "static/outputs"
ALLOWED_EXTENSIONS = {"png", "jpg", "jpeg", "mp4", "avi"}

app = Flask(__name__)
app.config["UPLOAD_FOLDER"] = UPLOAD_FOLDER
app.config["OUTPUT_FOLDER"] = OUTPUT_FOLDER
app.secret_key = "supersecretkey"

# make sure directories exist
os.makedirs(UPLOAD_FOLDER, exist_ok=True)
os.makedirs(OUTPUT_FOLDER, exist_ok=True)

# instantiate detector; fallback to Haar if YOLO files missing
try:
    detector = AnimalDetector(use_yolo=True)
except Exception as e:
    print("YOLO not available, falling back to Haar cascade. ", e)
    detector = AnimalDetector(use_yolo=False)


def allowed_file(filename):
    return "." in filename and filename.rsplit(".", 1)[1].lower() in ALLOWED_EXTENSIONS


def get_image_gps(filepath):
    """Try to read GPS latitude and longitude from image EXIF if present."""
    try:
        image = Image.open(filepath)
        exif_data = image._getexif() or {}
        gps_info = {}
        for tag, value in exif_data.items():
            decoded = TAGS.get(tag, tag)
            if decoded == "GPSInfo":
                gps_info = value
        # NOTE: proper conversion of DMS to decimal needed; omitted for brevity
        # return (lat, lon) or None
    except Exception:
        pass
    return None


@app.route("/", methods=["GET", "POST"])
def index():
    if request.method == "POST":
        if "file" not in request.files:
            flash("No file part")
            return redirect(request.url)
        file = request.files["file"]
        if file.filename == "":
            flash("No selected file")
            return redirect(request.url)
        if file and allowed_file(file.filename):
            filename = secure_filename(file.filename)
            upload_path = os.path.join(app.config["UPLOAD_FOLDER"], filename)
            file.save(upload_path)

            # detect animals
            if filename.rsplit('.',1)[1].lower() in ['mp4','avi']:
                # simple implementation: process first frame only
                cap = cv2.VideoCapture(upload_path)
                ret, frame = cap.read()
                cap.release()
                image = frame
            else:
                image = cv2.imread(upload_path)

            boxes, confs, class_ids = detector.detect(image)
            output_img = draw_boxes(image.copy(), boxes, confs, class_ids, detector.classes if detector.use_yolo else None)

            out_name = f"det_{filename.rsplit('.',1)[0]}.jpg"
            out_path = os.path.join(app.config["OUTPUT_FOLDER"], out_name)
            cv2.imwrite(out_path, output_img)

            # get optional GPS data
            gps = get_image_gps(upload_path)
            if not gps:
                # default coordinates or random for demonstration
                gps = (-1.2921, 36.8219)  # Nairobi as placeholder

            return render_template("result.html",
                                   original=url_for('static', filename=f"uploads/{filename}"),
                                   output=url_for('static', filename=f"outputs/{out_name}"),
                                   gps=gps)
    return render_template("index.html")


if __name__ == "__main__":
    app.run(debug=True)
