import cv2
import numpy as np
import os
from pathlib import Path

# Paths for YOLO files (not included due to size)
BASE_DIR = Path(__file__).parent
YOLO_DIR = BASE_DIR / "models"


class AnimalDetector:
    def __init__(self, use_yolo=True):
        self.use_yolo = use_yolo
        self.net = None
        self.output_layers = []
        self.classes = []

        if use_yolo:
            self._load_yolo()
        else:
            self.cascade = self._load_haar()

    def _load_yolo(self):
        cfg = YOLO_DIR / "yolov3.cfg"
        weights = YOLO_DIR / "yolov3.weights"
        names = YOLO_DIR / "coco.names"

        if not cfg.exists() or not weights.exists() or not names.exists():
            raise FileNotFoundError(
                "YOLO configuration/weights/names files not found in models/. "
                "Please download from https://pjreddie.com/darknet/yolo/ or "
                "see README for instructions."
            )

        self.net = cv2.dnn.readNet(str(weights), str(cfg))
        self.classes = [line.strip() for line in open(str(names))]
        layer_names = self.net.getLayerNames()
        self.output_layers = [layer_names[i - 1] for i in self.net.getUnconnectedOutLayers().flatten()]

    def _load_haar(self):
        # You can replace with any cascade xml for animals
        cascade_path = cv2.data.haarcascades + "haarcascade_frontalcatface.xml"
        return cv2.CascadeClassifier(cascade_path)

    def detect(self, image):
        """Return list of bounding boxes and confidences of animals in the image."""
        if self.use_yolo and self.net is not None:
            return self._detect_yolo(image)
        else:
            return self._detect_haar(image)

    def _detect_yolo(self, image):
        height, width = image.shape[:2]
        blob = cv2.dnn.blobFromImage(image, 1 / 255.0, (416, 416), swapRB=True, crop=False)
        self.net.setInput(blob)
        outs = self.net.forward(self.output_layers)

        boxes = []
        confidences = []
        class_ids = []

        for out in outs:
            for detection in out:
                scores = detection[5:]
                class_id = np.argmax(scores)
                confidence = float(scores[class_id])
                # filter only common animal classes in COCO
                if confidence > 0.3 and self.classes[class_id] in (
                    "person",
                    "dog",
                    "cat",
                    "horse",
                    "cow",
                    "sheep",
                    "bird",
                    "pottedplant",
                ):
                    center_x = int(detection[0] * width)
                    center_y = int(detection[1] * height)
                    w = int(detection[2] * width)
                    h = int(detection[3] * height)
                    x = int(center_x - w / 2)
                    y = int(center_y - h / 2)
                    boxes.append([x, y, w, h])
                    confidences.append(confidence)
                    class_ids.append(class_id)
        return boxes, confidences, class_ids

    def _detect_haar(self, image):
        gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
        animals = self.cascade.detectMultiScale(gray, scaleFactor=1.1, minNeighbors=5)
        boxes = []
        for (x, y, w, h) in animals:
            boxes.append([x, y, w, h])
        return boxes, [1.0] * len(boxes), [0] * len(boxes)


def draw_boxes(image, boxes, confidences=None, class_ids=None, classes=None):
    for i, box in enumerate(boxes):
        x, y, w, h = box
        cv2.rectangle(image, (x, y), (x + w, y + h), (0, 255, 0), 2)
        if confidences and class_ids is not None and classes:
            label = f"{classes[class_ids[i]]}:{confidences[i]:.2f}"
            cv2.putText(image, label, (x, y - 5), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 255, 0), 1)
    return image
