# Animal Herd Detection

This Flask-based web application allows you to upload images or short videos and detects groups of animals using OpenCV with either YOLO (recommended) or a Haar cascade fallback. A map (using Leaflet and OpenStreetMap) marks the location where a herd was detected, demonstrating a bonus feature.

## Features

- Accepts image (`.png`, `.jpg`, `.jpeg`) and video (`.mp4`, `.avi`) uploads.
- Runs object detection to find animals and draws bounding boxes on the output image.
- Displays the original and processed image on a result page.
- Map alert showing the detected location (placeholder coordinates or EXIF GPS if available).

## Setup

1. **Create a Python environment** and activate it:
   ```bash
   python -m venv venv
   source venv/Scripts/activate    # Windows
   # or `source venv/bin/activate` on macOS/Linux
   ```

2. **Install dependencies**:
   ```bash
   pip install -r requirements.txt
   ```

3. **Download YOLO model files (optional but recommended for better accuracy)**

   Create a `models` directory next to `app.py` and download the following files:
   - `yolov3.weights` from https://pjreddie.com/media/files/yolov3.weights
   - `yolov3.cfg` from https://github.com/pjreddie/darknet/blob/master/cfg/yolov3.cfg
   - `coco.names` containing COCO class names (you can find lists online).

   After downloading, your `models` directory should contain those three files.  If they are not present, the application will fall back to a Haar cascade (`haarcascade_frontalcatface.xml`) which comes with OpenCV.

4. **Run the application**:
   ```bash
   python app.py
   ```

   Open `http://127.0.0.1:5000` in your browser.

## Usage

- Upload an image or a short video file containing animals.
- After submission, view the detection results and a map marking the location.
- For video files, only the first frame is processed.

## Map / Bonus Feature

- The map uses Leaflet and OpenStreetMap tiles.
- GPS coordinates are attempted to be read from the uploaded image's EXIF data. If not available, a placeholder coordinate (Nairobi) is used; you can modify this logic in `app.py`.

## Notes

- This is a simple prototype; accuracy depends heavily on the choice of detection model and the quality of input media.
- For large video support or real-time tracking additional work would be required.

## License

MIT License
