import os
import random
from datetime import datetime
from io import BytesIO
from textwrap import fill
from xml.sax.saxutils import escape

import requests
from dotenv import load_dotenv
from flask import Flask, jsonify, render_template, request, send_file
from reportlab.lib import colors
from reportlab.lib.enums import TA_CENTER
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
from reportlab.lib.units import inch
from reportlab.platypus import Paragraph, SimpleDocTemplate, Spacer


load_dotenv()

app = Flask(__name__)


STORY_TYPES = {
    "Adventure": "fast-paced adventure with brave choices, discovery, and wonder",
    "Horror": "spooky but school-appropriate horror with suspense, atmosphere, and a clever ending",
    "Funny": "lighthearted comedy with charming jokes, surprising situations, and warmth",
    "Romantic": "gentle romance with emotion, respect, and a heartfelt conclusion",
    "Mystery": "mystery with clues, tension, investigation, and a satisfying reveal",
    "Kids Story": "kid-friendly story with simple language, imagination, and a positive lesson",
}

STORY_LENGTHS = {
    "Short": {"words": "450 to 650", "tokens": 900},
    "Medium": {"words": "850 to 1200", "tokens": 1600},
    "Long": {"words": "1400 to 2000", "tokens": 2800},
}


@app.route("/")
def home():
    """Render the main application page."""
    return render_template("index.html")


@app.route("/generate", methods=["POST"])
def generate_story_route():
    """Generate a story from the selected topic, type, and length."""
    data = request.get_json(silent=True) or {}
    topic = clean_text(data.get("topic", ""))
    story_type = clean_text(data.get("story_type", "Adventure"))
    story_length = clean_text(data.get("story_length", "Short"))

    if not topic:
        return jsonify({"error": "Please enter a story topic first."}), 400

    if story_type not in STORY_TYPES:
        return jsonify({"error": "Please choose a valid story type."}), 400

    if story_length not in STORY_LENGTHS:
        return jsonify({"error": "Please choose a valid story length."}), 400

    try:
        story, provider = generate_story(topic, story_type, story_length)
        return jsonify(
            {
                "story": story,
                "provider": provider,
                "created_at": datetime.now().strftime("%B %d, %Y at %I:%M %p"),
            }
        )
    except Exception as exc:
        # The user should get a friendly message, while the console keeps the debug detail.
        print(f"Story generation failed: {exc}")
        story = generate_local_story(topic, story_type, story_length)
        return jsonify(
            {
                "story": story,
                "provider": "Local Demo Fallback",
                "created_at": datetime.now().strftime("%B %d, %Y at %I:%M %p"),
                "note": "The AI API could not be reached, so a local demo story was generated.",
            }
        )


@app.route("/download-pdf", methods=["POST"])
def download_pdf():
    """Create and return a PDF file for the generated story."""
    data = request.get_json(silent=True) or {}
    story = clean_text(data.get("story", ""))
    title = clean_text(data.get("title", "AI Story"))

    if not story:
        return jsonify({"error": "No story text was provided for the PDF."}), 400

    pdf_buffer = build_story_pdf(title, story)
    safe_title = "".join(ch if ch.isalnum() else "-" for ch in title.lower()).strip("-")
    download_name = f"{safe_title or 'ai-story'}.pdf"

    return send_file(
        pdf_buffer,
        as_attachment=True,
        download_name=download_name,
        mimetype="application/pdf",
    )


def clean_text(value):
    """Normalize user input so the API receives clear and safe text."""
    return str(value or "").strip()


def generate_story(topic, story_type, story_length):
    """Use Gemini first, then OpenAI, and finally a local fallback if no key exists."""
    prompt = build_story_prompt(topic, story_type, story_length)

    if os.getenv("GEMINI_API_KEY"):
        return generate_with_gemini(prompt, story_length), "Gemini API"

    if os.getenv("OPENAI_API_KEY"):
        return generate_with_openai(prompt, story_length), "OpenAI API"

    return generate_local_story(topic, story_type, story_length), "Local Demo Fallback"


def build_story_prompt(topic, story_type, story_length):
    """Build one consistent prompt for any supported AI provider."""
    length_details = STORY_LENGTHS[story_length]
    story_style = STORY_TYPES[story_type]

    return f"""
Write a unique {story_length.lower()} {story_type.lower()} story about:
"{topic}"

Creative direction:
- Style: {story_style}.
- Length: about {length_details["words"]} words.
- Structure: include a memorable title, a strong opening hook, a clear beginning, middle, and ending.
- Voice: human-like, vivid, polished, and easy to understand.
- Make the story original. Avoid copying known movies, books, or fairy tales.
- Keep the content appropriate for a school project.
- Return only the story text with natural paragraph breaks.
""".strip()


def generate_with_gemini(prompt, story_length):
    """Generate text using the Gemini REST API."""
    api_key = os.getenv("GEMINI_API_KEY")
    model = os.getenv("GEMINI_MODEL", "gemini-2.5-flash")
    url = f"https://generativelanguage.googleapis.com/v1beta/models/{model}:generateContent"

    payload = {
        "system_instruction": {
            "parts": [
                {
                    "text": (
                        "You are an award-winning storyteller for students. "
                        "Write creative, emotionally clear, classroom-safe stories."
                    )
                }
            ]
        },
        "contents": [{"role": "user", "parts": [{"text": prompt}]}],
        "generationConfig": {
            "temperature": 0.9,
            "topP": 0.95,
            "maxOutputTokens": STORY_LENGTHS[story_length]["tokens"],
        },
    }

    response = requests.post(
        url,
        headers={"Content-Type": "application/json", "x-goog-api-key": api_key},
        json=payload,
        timeout=75,
    )
    response.raise_for_status()
    data = response.json()

    candidates = data.get("candidates", [])
    if not candidates:
        raise ValueError("Gemini returned no story candidates.")

    parts = candidates[0].get("content", {}).get("parts", [])
    story = "\n".join(part.get("text", "") for part in parts).strip()

    if not story:
        raise ValueError("Gemini returned an empty story.")

    return story


def generate_with_openai(prompt, story_length):
    """Generate text using OpenAI's Responses API."""
    api_key = os.getenv("OPENAI_API_KEY")
    model = os.getenv("OPENAI_MODEL", "gpt-5.2")
    url = "https://api.openai.com/v1/responses"

    payload = {
        "model": model,
        "instructions": (
            "You are an award-winning storyteller for students. "
            "Write creative, emotionally clear, classroom-safe stories."
        ),
        "input": prompt,
        "max_output_tokens": STORY_LENGTHS[story_length]["tokens"],
    }

    response = requests.post(
        url,
        headers={"Content-Type": "application/json", "Authorization": f"Bearer {api_key}"},
        json=payload,
        timeout=75,
    )
    response.raise_for_status()
    data = response.json()

    story = data.get("output_text") or extract_openai_output_text(data)
    if not story:
        raise ValueError("OpenAI returned an empty story.")

    return story.strip()


def extract_openai_output_text(data):
    """Read text from the Responses API output array when output_text is unavailable."""
    pieces = []
    for item in data.get("output", []):
        for content in item.get("content", []):
            if content.get("type") in {"output_text", "text"}:
                pieces.append(content.get("text", ""))
    return "\n".join(piece for piece in pieces if piece).strip()


def generate_local_story(topic, story_type, story_length):
    """Create a polished demo story so the app is usable before an API key is added."""
    settings = {
        "Adventure": {
            "title": "The Map That Chose {topic}",
            "mood": "golden and restless",
            "challenge": "a path that appeared only when someone was brave enough to begin",
            "lesson": "courage grows one honest step at a time",
        },
        "Horror": {
            "title": "The Whisper Behind {topic}",
            "mood": "moonlit and uneasy",
            "challenge": "a whisper that knew everyone's name but asked for only one secret",
            "lesson": "fear becomes smaller when the truth is brought into the light",
        },
        "Funny": {
            "title": "The Ridiculous Trouble With {topic}",
            "mood": "bright, bouncy, and slightly chaotic",
            "challenge": "a problem that got funnier every time someone tried to fix it",
            "lesson": "sometimes the best plan is to laugh, breathe, and try again",
        },
        "Romantic": {
            "title": "A Letter Hidden Near {topic}",
            "mood": "soft and hopeful",
            "challenge": "two shy hearts trying to say the right thing at the right time",
            "lesson": "love is often built from small, brave kindnesses",
        },
        "Mystery": {
            "title": "The Secret of {topic}",
            "mood": "misty and curious",
            "challenge": "three clues that refused to make sense until midnight",
            "lesson": "patience can hear what hurry misses",
        },
        "Kids Story": {
            "title": "The Little Wonder of {topic}",
            "mood": "sparkly, kind, and full of questions",
            "challenge": "a tiny problem that needed a big imagination",
            "lesson": "kindness is a magic everyone can use",
        },
    }

    selected = settings[story_type]
    title = selected["title"].format(topic=topic.title())
    paragraph_count = {"Short": 5, "Medium": 8, "Long": 12}[story_length]
    names = ["Ayan", "Mira", "Zara", "Kabir", "Lina", "Ray"]
    hero = random.choice(names)

    paragraphs = [
        (
            f"{title}\n\n"
            f"{hero} first noticed that {topic} felt different on a {selected['mood']} afternoon. "
            f"Everyone else walked past it as if it were ordinary, but {hero} saw the small signs: "
            "a shimmer at the edge, a hush in the air, and the strange feeling that something was waiting."
        ),
        (
            f"By sunset, the waiting became a challenge: {selected['challenge']}. "
            f"{hero} wanted to run home, yet curiosity tugged harder than fear. "
            "With a deep breath, the kind people in the neighborhood watching from windows, "
            f"and one brave idea flickering like a candle, {hero} stepped forward."
        ),
        (
            "The world changed in little details first. Shadows stretched into secret arrows. "
            "A loose button on a coat became a clue. Even the wind seemed to speak in half-sentences. "
            f"{hero} followed each sign carefully, learning that the mystery of {topic} was not trying "
            "to scare anyone; it was trying to be understood."
        ),
    ]

    middle_templates = [
        (
            f"At the heart of it all, {hero} found a locked wooden box. It was not opened by a key, "
            "but by remembering the kindest thing someone had done that day. The moment the memory "
            "was spoken aloud, the box clicked open like it had been waiting for gratitude."
        ),
        (
            "Inside was a folded note covered in tiny silver lines. The note did not give answers "
            "directly. Instead, it asked better questions. Who had been overlooked? What had been "
            "forgotten? Why did small things matter so much when the world felt too large?"
        ),
        (
            f"{hero} gathered courage from every answer. A neighbor's smile became a lantern, "
            "a friend's joke became a bridge, and a mistake from earlier in the day became the exact "
            "solution nobody expected."
        ),
        (
            f"When the final obstacle rose up, {hero} did not defeat it with force. "
            "The answer was gentler: listen first, speak honestly, and refuse to leave anyone behind. "
            "The obstacle softened, as if it had only wanted someone to understand its shape."
        ),
        (
            "For a moment, everything became still. Then the air filled with warm color. "
            f"The secret of {topic} unfolded, not as a prize, but as a promise that ordinary places "
            "can hold extraordinary meanings for those who pay attention."
        ),
        (
            f"{hero} laughed then, partly from relief and partly because the day had become stranger "
            "than any story in a library. The laugh bounced from wall to wall until even the serious "
            "old clock nearby seemed to tick with better humor."
        ),
        (
            "The people who had watched from far away finally came closer. They did not ask for proof. "
            f"They could see it in {hero}'s face: something difficult had been faced, and something "
            "beautiful had been brought back."
        ),
        (
            f"Before leaving, {hero} noticed one last sign near {topic}: a small mark shaped like a door. "
            "It reminded everyone that endings are often invitations in disguise. What mattered most was "
            "not the magic itself, but the way it had made ordinary people braver and kinder."
        ),
        (
            "The next morning, the town felt freshly painted. People greeted each other with warmer voices, "
            "children searched corners for hidden clues, and even the busiest adults paused long enough to "
            "wonder whether they had been walking past quiet miracles for years."
        ),
    ]

    paragraphs.extend(middle_templates[: max(0, paragraph_count - 4)])
    paragraphs.append(
        (
            f"By the time the stars appeared, {topic} looked ordinary again, but nobody treated it "
            f"as ordinary anymore. {hero} carried the lesson home carefully: {selected['lesson']}. "
            "And whenever someone passed that place after dark, they walked a little slower, hoping "
            "to notice the next small miracle before it disappeared."
        )
    )

    return "\n\n".join(paragraphs)


def build_story_pdf(title, story):
    """Build a clean PDF document in memory."""
    buffer = BytesIO()
    doc = SimpleDocTemplate(
        buffer,
        pagesize=A4,
        rightMargin=0.7 * inch,
        leftMargin=0.7 * inch,
        topMargin=0.65 * inch,
        bottomMargin=0.65 * inch,
    )

    styles = getSampleStyleSheet()
    title_style = ParagraphStyle(
        "StoryTitle",
        parent=styles["Title"],
        alignment=TA_CENTER,
        fontName="Times-Bold",
        fontSize=22,
        leading=28,
        textColor=colors.HexColor("#12343B"),
        spaceAfter=18,
    )
    body_style = ParagraphStyle(
        "StoryBody",
        parent=styles["BodyText"],
        fontName="Times-Roman",
        fontSize=11.5,
        leading=17,
        textColor=colors.HexColor("#1E293B"),
        spaceAfter=12,
    )
    footer_style = ParagraphStyle(
        "Footer",
        parent=styles["BodyText"],
        alignment=TA_CENTER,
        fontName="Times-Italic",
        fontSize=9,
        textColor=colors.HexColor("#64748B"),
        spaceBefore=18,
    )

    story_parts = [Paragraph(escape(title), title_style)]
    for paragraph in story.split("\n\n"):
        cleaned = " ".join(paragraph.split())
        if cleaned:
            story_parts.append(Paragraph(escape(fill(cleaned, width=95)), body_style))
            story_parts.append(Spacer(1, 4))

    story_parts.append(Paragraph("Created with AI Story Generator", footer_style))
    doc.build(story_parts)
    buffer.seek(0)
    return buffer


if __name__ == "__main__":
    app.run(debug=True)
