const form = document.getElementById("storyForm");
const topicInput = document.getElementById("topic");
const storyTypeInput = document.getElementById("storyType");
const storyLengthInput = document.getElementById("storyLength");
const generateBtn = document.getElementById("generateBtn");
const clearBtn = document.getElementById("clearBtn");
const copyBtn = document.getElementById("copyBtn");
const pdfBtn = document.getElementById("pdfBtn");
const loader = document.getElementById("loader");
const storyOutput = document.getElementById("storyOutput");
const providerLine = document.getElementById("providerLine");
const historyList = document.getElementById("historyList");
const clearHistoryBtn = document.getElementById("clearHistoryBtn");
const themeToggle = document.getElementById("themeToggle");
const themeText = document.getElementById("themeText");
const toast = document.getElementById("toast");

const HISTORY_KEY = "ai_story_generator_history";
let currentStory = "";
let currentTitle = "AI Story";

initializeTheme();
renderHistory();

form.addEventListener("submit", async (event) => {
    event.preventDefault();

    const payload = {
        topic: topicInput.value.trim(),
        story_type: storyTypeInput.value,
        story_length: storyLengthInput.value,
    };

    if (!payload.topic) {
        showToast("Please enter a story topic first.");
        topicInput.focus();
        return;
    }

    setLoading(true);

    try {
        const response = await fetch("/generate", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(payload),
        });

        const data = await response.json();
        if (!response.ok) {
            throw new Error(data.error || "Story generation failed.");
        }

        currentStory = data.story;
        currentTitle = extractTitle(data.story) || payload.topic;
        showStory(data.story, data.provider, data.created_at);
        saveToHistory({
            ...payload,
            story: data.story,
            provider: data.provider,
            created_at: data.created_at,
            title: currentTitle,
        });
        showToast(data.note || "Your story is ready.");
    } catch (error) {
        showToast(error.message || "Something went wrong. Please try again.");
    } finally {
        setLoading(false);
    }
});

clearBtn.addEventListener("click", () => {
    form.reset();
    currentStory = "";
    currentTitle = "AI Story";
    providerLine.textContent = "";
    storyOutput.classList.add("empty");
    storyOutput.innerHTML = "<p>Your generated story will appear here. Try a topic like \"a brave cat in a floating city\".</p>";
    copyBtn.disabled = true;
    pdfBtn.disabled = true;
    topicInput.focus();
    showToast("Workspace cleared.");
});

copyBtn.addEventListener("click", async () => {
    if (!currentStory) return;

    try {
        await navigator.clipboard.writeText(currentStory);
        showToast("Story copied to clipboard.");
    } catch {
        copyWithFallback(currentStory);
        showToast("Story copied to clipboard.");
    }
});

pdfBtn.addEventListener("click", async () => {
    if (!currentStory) return;

    pdfBtn.disabled = true;
    pdfBtn.textContent = "Preparing...";

    try {
        const response = await fetch("/download-pdf", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ title: currentTitle, story: currentStory }),
        });

        if (!response.ok) {
            const data = await response.json();
            throw new Error(data.error || "PDF download failed.");
        }

        const blob = await response.blob();
        const downloadUrl = URL.createObjectURL(blob);
        const link = document.createElement("a");
        link.href = downloadUrl;
        link.download = `${slugify(currentTitle)}.pdf`;
        document.body.appendChild(link);
        link.click();
        link.remove();
        URL.revokeObjectURL(downloadUrl);
        showToast("PDF downloaded.");
    } catch (error) {
        showToast(error.message || "Could not download PDF.");
    } finally {
        pdfBtn.disabled = false;
        pdfBtn.textContent = "Download PDF";
    }
});

clearHistoryBtn.addEventListener("click", () => {
    localStorage.removeItem(HISTORY_KEY);
    renderHistory();
    showToast("Story history cleared.");
});

themeToggle.addEventListener("click", () => {
    const currentTheme = document.documentElement.dataset.theme || "light";
    const nextTheme = currentTheme === "dark" ? "light" : "dark";
    applyTheme(nextTheme);
    localStorage.setItem("ai_story_theme", nextTheme);
});

function setLoading(isLoading) {
    generateBtn.disabled = isLoading;
    clearBtn.disabled = isLoading;
    generateBtn.innerHTML = `<span class="btn-shine"></span>${isLoading ? "Generating..." : "Generate Story"}`;
    loader.classList.toggle("hidden", !isLoading);
    storyOutput.classList.toggle("hidden", isLoading);
    providerLine.textContent = isLoading ? "" : providerLine.textContent;
}

function showStory(story, provider, createdAt) {
    storyOutput.classList.remove("empty", "hidden");
    storyOutput.innerHTML = formatStory(story);
    providerLine.textContent = `Generated with ${provider} on ${createdAt}.`;
    copyBtn.disabled = false;
    pdfBtn.disabled = false;
}

function formatStory(story) {
    return story
        .split(/\n{2,}/)
        .filter(Boolean)
        .map((paragraph, index) => {
            const cleanParagraph = escapeHtml(paragraph).replace(/\n/g, "<br>");
            return index === 0 && cleanParagraph.length < 120
                ? `<p><strong>${cleanParagraph}</strong></p>`
                : `<p>${cleanParagraph}</p>`;
        })
        .join("");
}

function saveToHistory(item) {
    const history = getHistory();
    const updated = [item, ...history].slice(0, 8);
    localStorage.setItem(HISTORY_KEY, JSON.stringify(updated));
    renderHistory();
}

function getHistory() {
    try {
        return JSON.parse(localStorage.getItem(HISTORY_KEY)) || [];
    } catch {
        return [];
    }
}

function renderHistory() {
    const history = getHistory();

    if (!history.length) {
        historyList.innerHTML = "<p class=\"empty-history\">No stories yet. Generate one and it will be saved here.</p>";
        return;
    }

    historyList.innerHTML = "";
    history.forEach((item) => {
        const button = document.createElement("button");
        button.className = "history-item";
        button.type = "button";
        button.innerHTML = `
            <strong>${escapeHtml(item.title || item.topic)}</strong>
            <span>${escapeHtml(item.story_type)} • ${escapeHtml(item.story_length)} • ${escapeHtml(item.provider || "AI")}</span>
            <span>${escapeHtml(item.created_at || "Saved story")}</span>
        `;
        button.addEventListener("click", () => {
            currentStory = item.story;
            currentTitle = item.title || extractTitle(item.story) || item.topic;
            showStory(item.story, item.provider || "History", item.created_at || "your browser history");
            window.scrollTo({ top: storyOutput.offsetTop - 120, behavior: "smooth" });
        });
        historyList.appendChild(button);
    });
}

function initializeTheme() {
    const savedTheme = localStorage.getItem("ai_story_theme");
    const preferredTheme = window.matchMedia("(prefers-color-scheme: dark)").matches ? "dark" : "light";
    applyTheme(savedTheme || preferredTheme);
}

function applyTheme(theme) {
    document.documentElement.dataset.theme = theme;
    themeText.textContent = theme === "dark" ? "Light" : "Dark";
}

function showToast(message) {
    toast.textContent = message;
    toast.classList.add("show");
    clearTimeout(showToast.timeout);
    showToast.timeout = setTimeout(() => toast.classList.remove("show"), 2600);
}

function copyWithFallback(text) {
    const textarea = document.createElement("textarea");
    textarea.value = text;
    textarea.style.position = "fixed";
    textarea.style.opacity = "0";
    document.body.appendChild(textarea);
    textarea.select();
    document.execCommand("copy");
    textarea.remove();
}

function extractTitle(story) {
    return story
        .split("\n")
        .map((line) => line.trim())
        .find((line) => line.length > 0 && line.length < 90)
        ?.replace(/^#+\s*/, "");
}

function escapeHtml(value) {
    return String(value)
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;")
        .replace(/"/g, "&quot;")
        .replace(/'/g, "&#039;");
}

function slugify(value) {
    return String(value || "ai-story")
        .toLowerCase()
        .replace(/[^a-z0-9]+/g, "-")
        .replace(/^-+|-+$/g, "")
        || "ai-story";
}
